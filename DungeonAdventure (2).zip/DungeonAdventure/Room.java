
public class Room {
	
	public Room(){
		
	}
	
	public void HealingPotion() {
		//adds 5-15 points to character
	}
	
	public void Pit() {
		System.out.print("You have fallen into a pit");
		//does anywhere from 1-20 damage
	}
	
	public void Entrance() {
		System.out.print("You have reached the entrance of the dungeon");
		
	}
	
	public void Exit() {
		System.out.print("You found the exit!!!");
	}
	
	public void pillarOfOO() {
		System.out.print("You have acquired the first pillar of OO");
	}
	
	public void 
}
