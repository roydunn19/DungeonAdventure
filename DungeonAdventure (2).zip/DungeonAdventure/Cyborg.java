
public class Cyborg {

}
