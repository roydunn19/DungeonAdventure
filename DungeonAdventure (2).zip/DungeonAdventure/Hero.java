
public abstract class Hero {
	
	public String name;
	int hitPoints, totalHealingPotions, totalVisionPotions, pillarsOfOO;
	
	public Hero() {}
	
	public int getLocation() {
		int coordinates = 0;
		//calls array class and gets coordinates	
		return coordinates;
	}
	
	public void updateHero() {
		//need dungeon class for this.
	}
	
	
}
