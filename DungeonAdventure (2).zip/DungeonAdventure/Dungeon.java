
public class Dungeon {

}
