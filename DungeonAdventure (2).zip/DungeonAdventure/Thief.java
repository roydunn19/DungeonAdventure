
public class Thief {

}
